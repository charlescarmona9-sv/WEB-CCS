// Mobile navigation toggle
(function () {
  'use strict';

  var toggle = document.getElementById('nav-toggle');
  var nav = document.getElementById('main-nav');
  if (!toggle || !nav) return;

  toggle.addEventListener('click', function () {
    var isOpen = nav.classList.toggle('is-open');
    toggle.setAttribute('aria-expanded', String(isOpen));
  });
})();

// Events: dim the ones whose date has already passed, and move them
// after the still-upcoming ones so "Upcoming events" leads with what's
// actually upcoming (relative order is preserved within each group).
(function () {
  'use strict';

  var items = document.querySelectorAll('.event-item[data-date]');
  if (!items.length) return;
  var today = new Date();
  today.setHours(0, 0, 0, 0);
  items.forEach(function (el) {
    var d = new Date(el.getAttribute('data-date') + 'T00:00:00');
    if (d < today) {
      el.classList.add('is-past');
      el.parentNode.appendChild(el);
    }
  });
})();

// Announcements: grey out the date chip once that date has passed
(function () {
  'use strict';

  var items = document.querySelectorAll('.announce-item[data-date]');
  if (!items.length) return;
  var today = new Date();
  today.setHours(0, 0, 0, 0);
  items.forEach(function (el) {
    var d = new Date(el.getAttribute('data-date') + 'T00:00:00');
    if (d < today) {
      el.classList.add('is-past');
      var chip = el.querySelector('.announce-date');
      if (chip) chip.title = 'This date has passed';
    }
  });
})();

// Header shrinks slightly once the page is scrolled.
// Two thresholds (hysteresis) are used on purpose: shrinking the header makes
// the page ~50-70px shorter, which nudges scrollY back down. With a single
// threshold that nudge flips the header straight back and it flickers forever.
// The gap between SHRINK_AT and EXPAND_AT must stay larger than that height change.
(function () {
  'use strict';
  var header = document.querySelector('header.site-header');
  if (!header) return;

  var SHRINK_AT = 120;  // scroll down past this -> compact header
  var EXPAND_AT = 10;   // scroll back up near the top -> full header
  var compact = false;
  var ticking = false;

  function update() {
    ticking = false;
    var y = window.scrollY;
    if (!compact && y > SHRINK_AT) compact = true;
    else if (compact && y < EXPAND_AT) compact = false;
    header.classList.toggle('is-scrolled', compact);
  }
  function onScroll() {
    if (ticking) return;
    ticking = true;
    window.requestAnimationFrame(update);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  update();
})();

// Gentle fade-in as sections scroll into view
(function () {
  'use strict';
  if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var targets = document.querySelectorAll('.home-section, .quickfacts-band, .main-col > section, .side-col .side-block');
  if (!targets.length) return;
  document.documentElement.classList.add('js');
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) { e.target.classList.add('is-visible'); io.unobserve(e.target); }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
  targets.forEach(function (t) { t.classList.add('reveal'); io.observe(t); });
})();
